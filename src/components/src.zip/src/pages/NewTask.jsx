import TaskForm from "../components/taskForm/TaskForm";

export default function NewTaskPage(){

  return (
    <TaskForm method="post" />
  )
}

