export default function AuthPage(){

  return (
    <>  
      <h1>AuthPage</h1>
    </>
    
  )
}