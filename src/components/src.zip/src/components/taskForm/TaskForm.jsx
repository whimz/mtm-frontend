import { useState } from 'react';
import { useNavigate, useParams, useRevalidator } from 'react-router-dom';
import { useForm, FormProvider } from 'react-hook-form';
import { 
  BasicDetailsSection, 
  ScheduleTimeSection, 
  ActionsSection,
} from './sections';
import ErrorDisplaySection from './sections/ErrorDisplaySection';
import { formatDateTime } from '../../util/helpers';
import classes from './TaskForm.module.css';


export default function TaskForm({ task }) {
  const [serverErrors, setServerErrors] = useState(null);
  const navigate = useNavigate();
  const { projectId } = useParams();
  const revalidator = useRevalidator();

  const form = useForm({
    defaultValues: {
      title: task?.title || '',
      description: task?.description || '',
      url: task?.url || '',
      taskInputs: task?.inputs || {},
      scheduleType: task?.cron_expression ? 'cron' : 'single', // ← This controls default radio
      scheduleTime: task?.launch_time?.slice(0, -3) || '',
      cronExpression: task?.cron_expression || '',
      createdOn: task?.createdOn || formatDateTime(new Date()),
      changedOn: formatDateTime(new Date())
    }
  })

  const onSubmit = async (data) => {
    try {

      setServerErrors(null);

      const token = localStorage.getItem("token")

      if (!token) {
        setServerErrors({ general: "Authentication required. Please log in." })
        return
      }

      const isEditing = !!task;
      const method = isEditing ? "PATCH" : "POST";
      const url = isEditing ? `http://localhost:8080/tasks/${task.id}` : "http://localhost:8080/tasks";

      const taskData = {
        title: data.title,
        description: data.description,
        url: data.url,
        inputs: data.taskInputs || {}, 
        scheduleType: data.scheduleType,
        scheduleTime: data.scheduleTime ? (data.scheduleTime + ":00") : null,
        cronExpression: data.cronExpression,

      };

      // Only include project_id when CREATING a new task
      if (!isEditing) {
        taskData.project_id = projectId
      }

      console.log("Submitting task data:", taskData)

      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: token,  
        },
        body: JSON.stringify(taskData)
      });

      if (response.status === 422) {
        const errorData = await response.json();
        setServerErrors(errorData.errors);
        return;
      }

      if (!response.ok) {
        console.log(response);
        throw new Error('Could not save task');
      } 

      // Success - redirect to project
      revalidator.revalidate(); 
      navigate(`/projects/${projectId}`);
      
    } catch (error) {
      console.error('Submit error:', error);
      setServerErrors({ general: 'An error occurred while saving the task' });
    }
  };

  return (
    <FormProvider {...form}>
      <form className={classes.form} onSubmit={form.handleSubmit(onSubmit)}>
        <BasicDetailsSection />
        <ScheduleTimeSection />
        <ErrorDisplaySection errors={serverErrors} className={classes.errorList}/>
        <ActionsSection onCancel={() => navigate(`/projects/${projectId}`)} />
      </form>
    </FormProvider>
  );
}

